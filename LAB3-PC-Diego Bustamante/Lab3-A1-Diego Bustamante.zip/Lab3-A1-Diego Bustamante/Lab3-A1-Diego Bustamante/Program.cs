﻿Console.WriteLine("Hola, ingrese su nombre:");
string nombre = Console.ReadLine();
Console.WriteLine("¿Qué curso está tomando?");
string curso = Console.ReadLine();
Console.WriteLine("Hola " + nombre + "Bienvenido a " + curso);
Console.WriteLine("Lo bueno que estás en sistemas, imagináte ser de psico ");
Console.ReadKey();
